<?php

use Monolog\Handler\StreamHandler;
use Monolog\Logger;
use sms\core\Config;
use sms\core\Request;
use sms\core\Router;
use sms\util\DependencyInjector;

require_once __DIR__ . '/vendor/autoload.php';

$config = new Config();

$dbConfig = $config->get('db');
//print_r($dbConfig);
$db = new PDO(
        "pgsql:host=localhost;dbname=sms;user=".$dbConfig['application']['user'].";password=".$dbConfig['application']['password'].";"
);

$loader = new Twig_Loader_Filesystem(__DIR__ . '/views');
//$view = new Twig_Environment($loader);
$view = new Twig_Environment($loader, ['debug'=>true]);
$view->addExtension(new Twig_Extension_Debug());

$log = new Logger('sms');
$logFile = $config->get('log');
$log->pushHandler(new StreamHandler($logFile, Logger::DEBUG));

$di = new DependencyInjector();
$di->set('PDO', $db);
$di->set('Utils\Config', $config);
$di->set('Twig_Environment', $view);
$di->set('Logger', $log);

$router = new Router($di);
$response = $router->route(new Request());
echo $response;

//
//echo $view->loadTemplate('bioinfo.twig')->render([]);