<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace sms\controller;

use sms\domain\Class_;
use sms\model\ClassModel;

/**
 * Description of ClassController
 *
 * @author root
 */
class ClassController extends AbstractController{
    //put your code here
     //put your code here
    
    public function newClass() {
        $classRmCont = new ClassroomController($this->di, $this->request);
        $arr = $classRmCont->getAll();
        return $this->render("management/createclass.twig",["cr"=>$arr]);
    }
    public function persist() {
        $result = false;
        $class = new Class_();
        $params = $this->request->getParams();
        $cookies = $this->request->getCookies();
        $properties = ['uname' => $cookies->get('uname')];

        $class->setVclass(strtoupper($params->getString("vclass")));
        $class->setVclassname(strtoupper($params->getString('vclassname')));
        $class->setVclassteacher(strtoupper($params->getString('vclassteacher')));
        $class->setVclassroom(strtoupper($params->getString('vclassroom')));

        //$appCont = new ApplicationController($this->di, $this->request);


        $model = new ClassModel($this->db);
        $result = $model->persist($class);
        //return $result;
        if ($result) {
            return $this->render('management/createclass.twig', ['msg'=>'Class successfully created']);
        } else {
            return $this->render('management/createclass.twig', ['msg'=>'Class creation failed']);
        }
//        if ($result) {
//            $appCont = new ApplicationController($this->di, $this->request);
//            $app = $appCont->get($cookies->getString('app'));
//            $app->setVeducation_info($class->getVeducation_info());
//            if ($appCont->update($app)) {
//                return $this->render('application/sibling.twig', $properties);
//            } else {
//                return $this->render('error.twig', ['errorMessage' => 'Could not update Application Table']);
//            }
//        } else {
//            return $this->render('error.twig', []);
//        }
    }
    
    public function get(string $vclass): Class_ {
        $model = new ClassModel($this->db);
        return $model->get($vclass);
    }
    public function getAll() {
        $model = new ClassModel($this->db);
        return $model->getAll();
    }
}
