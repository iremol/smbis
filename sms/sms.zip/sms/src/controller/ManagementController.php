<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace sms\controller;

/**
 * Description of ManagementController
 *
 * @author imole akpobome <imole.akpobome@gmail.com>
 * @version 1.0
 */
class ManagementController extends AbstractController {
    public function showCreateDept() {       
        return $this->render('management/createdept.twig', []);
    }
    /**
     * @name showCreatePos
     * @return string
     */
    public function showCreatePos() {       
        return $this->render('management/createpos.twig', []);
    }
}
